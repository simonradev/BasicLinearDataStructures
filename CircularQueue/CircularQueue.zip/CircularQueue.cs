﻿using System;

public class Test<T> : EventArgs
{
    public T[] array;
}

public class CircularQueue<TType>
{
    public EventHandler<Test<TType>> CollectionChanged;

    private const int DefaultCapacity = 4;

    private int count;
    private int currentCapacity;

    private int startIndex;
    private int endIndex;

    private int currentIndex;

    private TType[] allElements;
    
    public int Count { get { return this.count; } }

    public CircularQueue(int capacity = DefaultCapacity)
    {
        this.count = 0;
        this.currentCapacity = capacity;

        this.startIndex = 0;
        this.endIndex = 1;

        this.currentIndex = 0; 

        this.allElements = new TType[capacity];
    }

    public void Enqueue(TType element)
    {
        if (this.startIndex == this.endIndex)
        {
            this.Resize();
        }

        this.allElements[this.currentIndex] = element;

        this.currentIndex = this.CalculateIndex(this.currentIndex + 1);
        this.endIndex = this.currentIndex;

        this.count++;

        OnCollectionChanged();
    }

    public TType Dequeue()
    {
        if (this.count == 0)
        {
            throw new InvalidOperationException();
        }

        TType elementToReturn = this.allElements[this.startIndex];

        this.startIndex = this.CalculateIndex(this.startIndex + 1);
        this.count--;
        
        OnCollectionChanged();
        return elementToReturn;
    }

    protected virtual void OnCollectionChanged()
    {
        CollectionChanged?.Invoke(this, new Test<TType> { array = this.ToArray() });
    }

    private void Resize()
    {
        this.currentCapacity *= 2;

        TType[] holderArray = new TType[this.currentCapacity];

        int indexForAllElementsArray = this.startIndex;
        for (int currentElement = 0; currentElement < this.allElements.Length; currentElement++)
        {
            holderArray[currentElement] = this.allElements[this.CalculateIndex(indexForAllElementsArray++)];
        }

        this.allElements = holderArray;

        this.startIndex = 0;
        this.endIndex = indexForAllElementsArray;
        this.currentIndex = indexForAllElementsArray;
    }

    private void CopyAllElements(TType[] newArray)
    {
        newArray = this.ToArray();
    }
    
    public TType[] ToArray()
    {
        TType[] arrayToReturn = new TType[this.count];

        int loopStartIndex = this.startIndex;
        int loopEndIndex = this.startIndex + this.count;

        for (int currentElement = loopStartIndex, arrToReturnElement = 0; currentElement < loopEndIndex; currentElement++, arrToReturnElement++)
        {
            arrayToReturn[arrToReturnElement] = this.allElements[this.CalculateIndex(currentElement)];
        }

        return arrayToReturn;
    }

    private int CalculateIndex(int indexToCalculate)
    {
        return indexToCalculate % this.allElements.Length;
    }
}
